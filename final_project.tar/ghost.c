#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h> 
#include "defs.h"
#include "helpers.h"

/*
    ghost.c
*/

//sets id, ghost type, place ghost in starting room, boredom 0, not running
void ghost_init(struct Ghost* ghost, int id, enum GhostType type, struct Room* room) {
    ghost->id = id;
    ghost->type = type;
    ghost->current_room = room;
    ghost->boredom = 0;
    ghost->running = true;

    log_ghost_init(id, room->name, type);  //gives to log
    room->ghost = ghost;    //links ghost to room
}

//check for ghost's evidence 
bool ghost_has_evidence(enum GhostType ghost_type, enum EvidenceType evidence_type) {
    return (ghost_type & evidence_type) == evidence_type;   
}

//ghost drops the evidence
void ghost_drop_evidence(struct Ghost* ghost) {
    struct Room* room = ghost->current_room;
    
    const enum EvidenceType* evidence_list = NULL;
    int count = get_all_evidence_types(&evidence_list);
    
    enum EvidenceType target_evidence = 0;
    while (true) {
        int idx = rand_int_threadsafe(0, count);
        if (ghost_has_evidence(ghost->type, evidence_list[idx])) {
            target_evidence = evidence_list[idx];
            break;
        }
    }

    sem_wait(&room->mutex);
    room->evidence |= target_evidence;
    sem_post(&room->mutex);

    log_ghost_evidence(ghost->id, ghost->boredom, room->name, target_evidence);
}

//Move ghost from room A to room B
void ghost_move(struct Ghost* ghost) {
    struct Room* current = ghost->current_room;  //pointer to current ghost room
    
    
    if (current->connection_count == 0) return;   //check if room has any door, if not just stay there
     
    //find a door to go through
    int choice = rand_int_threadsafe(0, current->connection_count);
    struct Room* next = current->connections[choice];
    
    //if theres a ghost and a hunter moving into a room at the same time, we might get a deadlock
    //check their memory address and whichever is less, lock first
    struct Room* first = (current < next) ? current : next;
    struct Room* second = (current < next) ? next : current;
    
    //lock
    sem_wait(&first->mutex);
    sem_wait(&second->mutex);
    
    //move ghost from old room to new room 
    current->ghost = NULL;
    next->ghost = ghost;
    ghost->current_room = next;
    
    //unlock
    sem_post(&second->mutex);
    sem_post(&first->mutex);
    
    log_ghost_move(ghost->id, ghost->boredom, current->name, next->name);
}

//Main function for ghost thread
void* ghost_thread(void* arg) {
    struct Ghost* ghost = (struct Ghost*)arg;
    
    //Infinite loop that represents the ghost's life
    while (ghost->running) {
        struct Room* room = ghost->current_room;  //defein ghost's current room 
        bool hunter_present = false;    //initialize check if hunter is in room
        
        //other thread waits if the room is currentlly busy with the thread of the ghost (locking the keys for privacy)
        sem_wait(&room->mutex);
        
        //checks if the hunter is in the room when the key is locked
        if (room->hunter_count > 0) {
            hunter_present = true;
        }
        
        //opens the key, let other threads run
        sem_post(&room->mutex);
        
        //ghost sees hunter and do its thing while the boredom level goes to 0
        if (hunter_present) {
            ghost->boredom = 0;
            log_ghost_idle(ghost->id, ghost->boredom, room->name);
            
        //ghost dont see any hunter and gets more bored 
        } else {
            ghost->boredom++;
            
            //ghost reached max level of boredom and leaves
            if (ghost->boredom >= ENTITY_BOREDOM_MAX) {
                ghost->running = false;
                log_ghost_exit(ghost->id, ghost->boredom, room->name);
                pthread_exit(NULL);
            }
            
            //if ghost stills stays then it randomly chooses to do 1 of the 3 things
            int action = rand_int_threadsafe(0, 3);
            //Either ghost do nothing(idle), move to next room or drop evidence
            switch (action) {
                case 0: log_ghost_idle(ghost->id, ghost->boredom, room->name); break;
                case 1: ghost_move(ghost); break;
                case 2: ghost_drop_evidence(ghost); break;
            }
        }
        usleep(100 * 100);  //thread stop 0.1 seconds
    }
    return NULL;
}